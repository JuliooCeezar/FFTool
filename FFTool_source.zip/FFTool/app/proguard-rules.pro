# Mantém serviços e receivers
-keep class com.fftool.service.** { *; }
-keep class com.fftool.utils.BootReceiver { *; }
-keep class com.fftool.MainActivity { *; }

# Remove nomes de classe do APK final
-renamesourcefileattribute SourceFile
-keepattributes SourceFile,LineNumberTable

# Obfusca tudo mais
-obfuscationdictionary dict.txt
