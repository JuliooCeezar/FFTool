package com.fftool.engine;

import android.graphics.Point;
import android.util.DisplayMetrics;
import android.view.WindowManager;

import com.fftool.utils.Config;

import java.util.List;

/**
 * AimbotEngine
 * ────────────
 * Recebe a lista de inimigos detectados pelo ESPScanner,
 * seleciona o alvo mais próximo do centro da tela dentro do FOV,
 * calcula a posição de destino do gesto de aimbot e devolve
 * ao AimbotAccessibilityService que executa o gesto.
 */
public class AimbotEngine {

    public static class AimResult {
        public Point target;      // posição alvo na tela
        public int   enemyIndex;  // índice na lista de inimigos
        public AimResult(Point t, int i) { target = t; enemyIndex = i; }
    }

    private int screenW, screenH;
    private Point screenCenter;

    public AimbotEngine(WindowManager wm) {
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        screenW = dm.widthPixels;
        screenH = dm.heightPixels;
        screenCenter = new Point(screenW / 2, screenH / 2);
    }

    /**
     * Calcula melhor alvo para o aimbot.
     * @param enemies lista de inimigos detectados
     * @return AimResult com posição do alvo, ou null se nenhum no FOV
     */
    public AimResult calculate(List<ESPScanner.EnemyTarget> enemies) {
        if (enemies == null || enemies.isEmpty()) return null;
        if (!Config.AIMBOT_ENABLED) return null;

        ESPScanner.EnemyTarget best   = null;
        int                   bestIdx = -1;
        double                bestDist= Double.MAX_VALUE;
        int                   fov    = Config.AIMBOT_FOV;

        for (int i = 0; i < enemies.size(); i++) {
            ESPScanner.EnemyTarget e = enemies.get(i);

            // Ponto alvo baseado no osso configurado
            Point aimPoint = getAimPoint(e);

            // Distância do aimPoint até o centro da tela
            double dist = distance(aimPoint, screenCenter);

            // Só considera se dentro do FOV
            if (dist < fov && dist < bestDist) {
                bestDist = dist;
                best = e;
                bestIdx = i;
            }
        }

        if (best == null) return null;

        // Marca o inimigo como locked
        best.isLocked = true;

        // Aplica suavidade — interpola entre centro e alvo
        Point aimPoint = getAimPoint(best);
        Point smoothed = applySmoothness(aimPoint);

        return new AimResult(smoothed, bestIdx);
    }

    /** Retorna o ponto de mira baseado na configuração de osso */
    private Point getAimPoint(ESPScanner.EnemyTarget e) {
        switch (Config.AIMBOT_TARGET_BONE) {
            case 0: return e.headPos;   // cabeça
            case 1:                     // pescoço (entre cabeça e tórax)
                return new Point(
                    (e.headPos.x + e.chestPos.x) / 2,
                    (e.headPos.y + e.chestPos.y) / 2
                );
            case 2: return e.chestPos;  // tórax
            default: return e.headPos;
        }
    }

    /** Interpolação linear entre centro da tela e alvo com base no smooth */
    private Point applySmoothness(Point target) {
        float smooth = Config.AIMBOT_SMOOTH;
        if (smooth <= 0f) return target;

        // Quanto maior o smooth, mais gradual o movimento
        // smooth=0 → vai direto; smooth=1 → vai 50% do caminho por frame
        int dx = target.x - screenCenter.x;
        int dy = target.y - screenCenter.y;

        int newX = screenCenter.x + (int)(dx * (1f - smooth));
        int newY = screenCenter.y + (int)(dy * (1f - smooth));

        return new Point(newX, newY);
    }

    private double distance(Point a, Point b) {
        double dx = a.x - b.x;
        double dy = a.y - b.y;
        return Math.sqrt(dx * dx + dy * dy);
    }

    /** Retorna o centro da tela (crosshair) */
    public Point getScreenCenter() { return screenCenter; }
    public int getScreenW() { return screenW; }
    public int getScreenH() { return screenH; }
}
