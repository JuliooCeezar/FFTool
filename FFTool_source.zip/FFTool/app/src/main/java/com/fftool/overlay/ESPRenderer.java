package com.fftool.overlay;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.Build;
import android.view.View;
import android.view.WindowManager;

import com.fftool.engine.AimbotEngine;
import com.fftool.engine.ESPScanner;
import com.fftool.utils.Config;

import java.util.ArrayList;
import java.util.List;

/**
 * ESPRenderer
 * ───────────
 * View transparente sobreposta ao jogo que desenha:
 *  - Caixas 2D ao redor de cada inimigo detectado
 *  - Barra de HP
 *  - Distância em metros
 *  - Círculo de FOV do aimbot
 *  - Linha do crosshair até o alvo locked
 */
public class ESPRenderer extends View {

    private List<ESPScanner.EnemyTarget> enemies = new ArrayList<>();
    private AimbotEngine aimbotEngine;

    // Paints
    private Paint paintBox    = new Paint();
    private Paint paintBoxLck = new Paint();
    private Paint paintHP     = new Paint();
    private Paint paintHPBg   = new Paint();
    private Paint paintText   = new Paint();
    private Paint paintFOV    = new Paint();
    private Paint paintLine   = new Paint();
    private Paint paintCorner = new Paint();

    public ESPRenderer(Context ctx, AimbotEngine aimbot) {
        super(ctx);
        this.aimbotEngine = aimbot;
        initPaints();
    }

    private void initPaints() {
        // Caixa padrão
        paintBox.setStyle(Paint.Style.STROKE);
        paintBox.setStrokeWidth(Config.ESP_LINE_WIDTH);
        paintBox.setAntiAlias(true);

        // Caixa locked (aimbot mirando)
        paintBoxLck.setStyle(Paint.Style.STROKE);
        paintBoxLck.setStrokeWidth(Config.ESP_LINE_WIDTH + 1f);
        paintBoxLck.setAntiAlias(true);

        // HP fill
        paintHP.setStyle(Paint.Style.FILL);
        paintHP.setAntiAlias(true);

        // HP background
        paintHPBg.setStyle(Paint.Style.FILL);
        paintHPBg.setColor(Color.argb(150, 0, 0, 0));

        // Texto
        paintText.setColor(Color.WHITE);
        paintText.setTextSize(22f);
        paintText.setAntiAlias(true);
        paintText.setShadowLayer(3f, 1f, 1f, Color.BLACK);

        // FOV circle
        paintFOV.setStyle(Paint.Style.STROKE);
        paintFOV.setColor(Color.argb(80, 255, 255, 255));
        paintFOV.setStrokeWidth(1.5f);
        paintFOV.setAntiAlias(true);

        // Linha até alvo
        paintLine.setStyle(Paint.Style.STROKE);
        paintLine.setColor(Color.argb(180, 255, 255, 0));
        paintLine.setStrokeWidth(1.5f);
        paintLine.setAntiAlias(true);

        // Cantos da caixa (corner-box style)
        paintCorner.setStyle(Paint.Style.STROKE);
        paintCorner.setStrokeWidth(Config.ESP_LINE_WIDTH + 1f);
        paintCorner.setAntiAlias(true);
    }

    /** Atualiza lista de inimigos e redesenha */
    public void updateEnemies(List<ESPScanner.EnemyTarget> list) {
        this.enemies = list != null ? list : new ArrayList<>();
        postInvalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        if (!Config.ESP_ENABLED && !Config.AIMBOT_ENABLED) return;

        int cx = getWidth()  / 2;
        int cy = getHeight() / 2;

        // Atualiza cor da caixa conforme config atual
        paintBox.setColor(Config.ESP_COLOR_DEFAULT);
        paintBoxLck.setColor(Config.ESP_COLOR_LOCKED);
        paintCorner.setColor(Config.ESP_COLOR_DEFAULT);

        // Círculo de FOV
        if (Config.AIMBOT_ENABLED) {
            canvas.drawCircle(cx, cy, Config.AIMBOT_FOV, paintFOV);
        }

        if (!Config.ESP_ENABLED) return;

        for (ESPScanner.EnemyTarget e : enemies) {
            drawEnemy(canvas, e, cx, cy);
        }
    }

    private void drawEnemy(Canvas canvas, ESPScanner.EnemyTarget e, int cx, int cy) {
        Rect  b    = e.box;
        Paint boxP = e.isLocked ? paintBoxLck : paintBox;
        int   col  = e.isLocked ? Config.ESP_COLOR_LOCKED : Config.ESP_COLOR_DEFAULT;

        // ── Corner-box style ──────────────────────────────────
        int cLen = Math.max(8, b.width() / 5);
        paintCorner.setColor(col);

        // Top-left
        canvas.drawLine(b.left,         b.top,          b.left + cLen, b.top,          paintCorner);
        canvas.drawLine(b.left,         b.top,          b.left,        b.top + cLen,   paintCorner);
        // Top-right
        canvas.drawLine(b.right,        b.top,          b.right - cLen,b.top,          paintCorner);
        canvas.drawLine(b.right,        b.top,          b.right,       b.top + cLen,   paintCorner);
        // Bottom-left
        canvas.drawLine(b.left,         b.bottom,       b.left + cLen, b.bottom,       paintCorner);
        canvas.drawLine(b.left,         b.bottom,       b.left,        b.bottom - cLen,paintCorner);
        // Bottom-right
        canvas.drawLine(b.right,        b.bottom,       b.right - cLen,b.bottom,       paintCorner);
        canvas.drawLine(b.right,        b.bottom,       b.right,       b.bottom - cLen,paintCorner);

        // ── Barra de HP ───────────────────────────────────────
        if (Config.ESP_SHOW_HP) {
            int hpBarW  = 4;
            int hpBarH  = b.height();
            int hpX     = b.left - hpBarW - 3;
            RectF bgRect = new RectF(hpX, b.top, hpX + hpBarW, b.bottom);
            canvas.drawRect(bgRect, paintHPBg);

            float hpRatio = e.hp / 100f;
            int   hpColor = hpColor(e.hp);
            paintHP.setColor(hpColor);
            int hpTop = (int)(b.bottom - hpBarH * hpRatio);
            RectF hpRect = new RectF(hpX, hpTop, hpX + hpBarW, b.bottom);
            canvas.drawRect(hpRect, paintHP);
        }

        // ── Distância ─────────────────────────────────────────
        if (Config.ESP_SHOW_DIST) {
            String dist = String.format("%.0fm", e.distance);
            canvas.drawText(dist, b.centerX() - paintText.measureText(dist) / 2,
                    b.bottom + 20f, paintText);
        }

        // ── Linha até alvo (apenas locked) ───────────────────
        if (e.isLocked && Config.AIMBOT_ENABLED) {
            canvas.drawLine(cx, cy, e.headPos.x, e.headPos.y, paintLine);
        }

        // ── Ponto na cabeça ───────────────────────────────────
        Paint dotP = new Paint();
        dotP.setColor(col);
        dotP.setStyle(Paint.Style.FILL);
        canvas.drawCircle(e.headPos.x, e.headPos.y, 4f, dotP);
    }

    private int hpColor(int hp) {
        if (hp > 60) return Color.rgb(0, 220, 0);
        if (hp > 30) return Color.rgb(255, 165, 0);
        return Color.rgb(220, 0, 0);
    }

    /** Params para adicionar ao WindowManager como overlay transparente */
    public static WindowManager.LayoutParams buildLayoutParams() {
        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        return p;
    }
}
