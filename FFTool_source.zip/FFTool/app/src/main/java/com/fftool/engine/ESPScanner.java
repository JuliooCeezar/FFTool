package com.fftool.engine;

import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.graphics.Point;
import android.graphics.Rect;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.DisplayMetrics;
import android.view.WindowManager;

import com.fftool.utils.Config;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

/**
 * ESPScanner
 * ──────────
 * Usa MediaProjection para capturar frames do jogo e detecta
 * inimigos através de análise de cor/contorno — funciona
 * wallhack porque processa o frame renderizado completo,
 * incluindo silhuetas que o engine do FF desenha por baixo
 * de texturas de parede.
 *
 * Resultado: lista de Rect com bounding boxes de cada inimigo
 * detectado, repassada ao ESPRenderer para desenho do overlay.
 */
public class ESPScanner {

    public interface ScanCallback {
        void onEnemiesDetected(List<EnemyTarget> enemies);
    }

    // ── Resultado por inimigo ────────────────────────────────────
    public static class EnemyTarget {
        public Rect box;          // bounding box na tela
        public Point headPos;     // posição estimada da cabeça
        public Point chestPos;    // posição estimada do tórax
        public int   hp;          // HP estimado (via barra se visível)
        public float distance;    // distância estimada em metros
        public boolean isLocked;  // aimbot mirando nesse alvo

        public EnemyTarget(Rect box) {
            this.box = box;
            // Cabeça = topo do bounding box, centralizado
            this.headPos  = new Point(box.centerX(), box.top + (box.height() / 8));
            // Tórax = 35% do topo
            this.chestPos = new Point(box.centerX(), box.top + (box.height() * 35 / 100));
            this.hp       = 100;
            this.distance = estimateDistance(box.height());
            this.isLocked = false;
        }

        /** Estima distância baseado na altura da caixa em pixels */
        private float estimateDistance(int boxHeight) {
            if (boxHeight <= 0) return 0f;
            // Calibração empírica Free Fire 720p:
            // altura ~200px ≈ 10m, ~50px ≈ 50m
            return Math.max(1f, 2000f / boxHeight);
        }
    }

    // ── Campos ───────────────────────────────────────────────────
    private MediaProjection   projection;
    private ImageReader       imageReader;
    private VirtualDisplay    virtualDisplay;
    private HandlerThread     scanThread;
    private Handler           scanHandler;
    private ScanCallback      callback;
    private WindowManager     wm;

    private int screenW, screenH, screenDpi;
    private volatile boolean running = false;

    // ── Init ─────────────────────────────────────────────────────
    public ESPScanner(MediaProjection mp, WindowManager wm, ScanCallback cb) {
        this.projection = mp;
        this.wm = wm;
        this.callback = cb;

        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        screenW   = dm.widthPixels;
        screenH   = dm.heightPixels;
        screenDpi = dm.densityDpi;
    }

    public void start() {
        if (running) return;
        running = true;

        scanThread = new HandlerThread("ESPScanner");
        scanThread.start();
        scanHandler = new Handler(scanThread.getLooper());

        imageReader = ImageReader.newInstance(screenW, screenH,
                PixelFormat.RGBA_8888, 2);

        virtualDisplay = projection.createVirtualDisplay(
                "FFToolESP",
                screenW, screenH, screenDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader.getSurface(), null, scanHandler);

        imageReader.setOnImageAvailableListener(reader -> {
            if (!Config.ESP_ENABLED) return;
            Image img = reader.acquireLatestImage();
            if (img == null) return;
            try {
                Bitmap bmp = imageToBitmap(img);
                if (bmp != null) {
                    List<EnemyTarget> enemies = detectEnemies(bmp);
                    if (callback != null) callback.onEnemiesDetected(enemies);
                    bmp.recycle();
                }
            } finally {
                img.close();
            }
        }, scanHandler);
    }

    public void stop() {
        running = false;
        if (virtualDisplay != null) { virtualDisplay.release(); virtualDisplay = null; }
        if (imageReader   != null) { imageReader.close();      imageReader   = null; }
        if (projection    != null) { projection.stop();         projection   = null; }
        if (scanThread    != null) { scanThread.quitSafely();   scanThread   = null; }
    }

    // ── Bitmap do Image do MediaProjection ───────────────────────
    private Bitmap imageToBitmap(Image image) {
        try {
            Image.Plane plane  = image.getPlanes()[0];
            ByteBuffer  buffer = plane.getBuffer();
            int rowStride  = plane.getRowStride();
            int pixelStride= plane.getPixelStride();
            int rowPadding = rowStride - pixelStride * screenW;

            Bitmap bmp = Bitmap.createBitmap(
                    screenW + rowPadding / pixelStride,
                    screenH, Bitmap.Config.ARGB_8888);
            bmp.copyPixelsFromBuffer(buffer);

            // Crop para remover padding extra
            if (rowPadding != 0) {
                Bitmap cropped = Bitmap.createBitmap(bmp, 0, 0, screenW, screenH);
                bmp.recycle();
                return cropped;
            }
            return bmp;
        } catch (Exception e) {
            return null;
        }
    }

    // ── Detecção de inimigos por análise de cor ──────────────────
    /**
     * Free Fire renderiza um contorno/silhueta nos inimigos.
     * Escaneamos linhas verticais procurando clusters de pixels
     * com cor próxima do contorno de inimigo.
     * Resultado: bounding boxes dos clusters detectados.
     *
     * Para wallhack: o engine do FF ainda renderiza silhuetas
     * de inimigos atrás de paredes em alguns frames — nossa
     * varredura de pixel captura isso.
     */
    private List<EnemyTarget> detectEnemies(Bitmap bmp) {
        List<EnemyTarget> result = new ArrayList<>();

        int w = bmp.getWidth();
        int h = bmp.getHeight();
        int tol = Config.COLOR_TOLERANCE;
        int targetR = android.graphics.Color.red(Config.ENEMY_OUTLINE_COLOR);
        int targetG = android.graphics.Color.green(Config.ENEMY_OUTLINE_COLOR);
        int targetB = android.graphics.Color.blue(Config.ENEMY_OUTLINE_COLOR);

        // Mapa de hits para agrupar pixels próximos
        boolean[][] hitMap = new boolean[w][h];

        // Scan em grid 4x4 para performance
        for (int x = 0; x < w; x += 4) {
            for (int y = 0; y < h; y += 4) {
                int pixel = bmp.getPixel(x, y);
                int r = android.graphics.Color.red(pixel);
                int g = android.graphics.Color.green(pixel);
                int b = android.graphics.Color.blue(pixel);

                if (Math.abs(r - targetR) < tol &&
                    Math.abs(g - targetG) < tol &&
                    Math.abs(b - targetB) < tol) {
                    hitMap[x][y] = true;
                }
            }
        }

        // Clustering simples: agrupa hits próximos em bounding boxes
        boolean[][] visited = new boolean[w][h];
        int minClusterSize = 20; // pixels mínimos para ser um inimigo

        for (int x = 0; x < w; x += 4) {
            for (int y = 0; y < h; y += 4) {
                if (hitMap[x][y] && !visited[x][y]) {
                    // BFS para encontrar cluster
                    Rect bbox = new Rect(x, y, x, y);
                    int size = floodFill(hitMap, visited, x, y, w, h, bbox);

                    if (size >= minClusterSize) {
                        // Expande levemente o bounding box
                        int pad = 10;
                        bbox.left   = Math.max(0,  bbox.left   - pad);
                        bbox.top    = Math.max(0,  bbox.top    - pad * 3);
                        bbox.right  = Math.min(w,  bbox.right  + pad);
                        bbox.bottom = Math.min(h,  bbox.bottom + pad);

                        // Filtra boxes muito pequenas ou muito grandes
                        int bh = bbox.height();
                        int bw = bbox.width();
                        if (bh > 30 && bh < h * 0.8f && bw > 10 && bw < w * 0.4f) {
                            result.add(new EnemyTarget(bbox));
                        }
                    }
                }
            }
        }

        return result;
    }

    private int floodFill(boolean[][] map, boolean[][] visited,
                          int sx, int sy, int w, int h, Rect bbox) {
        // BFS iterativo
        java.util.LinkedList<int[]> queue = new java.util.LinkedList<>();
        queue.add(new int[]{sx, sy});
        int count = 0;
        int maxSpread = 60; // raio máximo do cluster

        while (!queue.isEmpty() && count < 500) {
            int[] p = queue.poll();
            int px = p[0], py = p[1];

            if (px < 0 || py < 0 || px >= w || py >= h) continue;
            if (visited[px][py]) continue;
            if (!map[px][py]) continue;
            if (Math.abs(px - sx) > maxSpread || Math.abs(py - sy) > maxSpread) continue;

            visited[px][py] = true;
            count++;

            // Atualiza bounding box
            if (px < bbox.left)   bbox.left   = px;
            if (py < bbox.top)    bbox.top     = py;
            if (px > bbox.right)  bbox.right   = px;
            if (py > bbox.bottom) bbox.bottom  = py;

            queue.add(new int[]{px + 4, py});
            queue.add(new int[]{px - 4, py});
            queue.add(new int[]{px, py + 4});
            queue.add(new int[]{px, py - 4});
        }
        return count;
    }
}
