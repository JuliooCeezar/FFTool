package com.fftool.service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.IBinder;
import android.view.WindowManager;

import com.fftool.engine.AimbotEngine;
import com.fftool.engine.ESPScanner;
import com.fftool.overlay.ESPRenderer;
import com.fftool.overlay.FloatingButton;
import com.fftool.utils.Config;

import java.util.List;

/**
 * OverlayService
 * ──────────────
 * Serviço foreground que orquestra:
 *  1. ESPScanner   → captura tela, detecta inimigos
 *  2. ESPRenderer  → overlay transparente com caixas ESP
 *  3. FloatingButton → botão + painel de config
 *  4. AimbotEngine + AimbotAccessibilityService → gestos de mira
 */
public class OverlayService extends Service {

    private static final String CHANNEL_ID = "fftool_fg";
    private static final int    NOTIF_ID   = 1;

    private WindowManager      wm;
    private MediaProjection    mp;
    private ESPScanner         scanner;
    private ESPRenderer        espRenderer;
    private AimbotEngine       aimbotEngine;
    private FloatingButton     floatBtn;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground(NOTIF_ID, buildNotification());

        int resultCode = intent.getIntExtra("resultCode", -1);
        Intent data    = intent.getParcelableExtra("data");

        wm = (WindowManager) getSystemService(WINDOW_SERVICE);

        // MediaProjection para ESP
        MediaProjectionManager mpm =
                (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        mp = mpm.getMediaProjection(resultCode, data);

        // Engines
        aimbotEngine = new AimbotEngine(wm);

        // ESP Renderer (overlay transparente)
        espRenderer = new ESPRenderer(this, aimbotEngine);
        wm.addView(espRenderer, ESPRenderer.buildLayoutParams());

        // Scanner
        scanner = new ESPScanner(mp, wm, enemies -> {
            // Atualiza renderer e aimbot
            espRenderer.updateEnemies(enemies);

            // Passa inimigos ao aimbot
            if (AimbotAccessibilityService.instance != null) {
                AimbotAccessibilityService.instance.updateEnemies(enemies);
            }
        });
        scanner.start();

        // Inicia loop do aimbot no serviço de acessibilidade
        if (AimbotAccessibilityService.instance != null) {
            AimbotAccessibilityService.instance.startAimbot(aimbotEngine);
        }

        // Botão flutuante
        floatBtn = new FloatingButton(this, wm, (espOn, aimOn) -> {
            // Callback de toggle — engine já atualizado pelo FloatingButton
            // via Config.*
            if (!aimOn && AimbotAccessibilityService.instance != null) {
                AimbotAccessibilityService.instance.stopLoop();
            } else if (aimOn && AimbotAccessibilityService.instance != null) {
                AimbotAccessibilityService.instance.startAimbot(aimbotEngine);
            }
        });
        floatBtn.attach();

        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (scanner    != null) scanner.stop();
        if (floatBtn   != null) floatBtn.detach();
        if (espRenderer!= null) {
            try { wm.removeView(espRenderer); } catch (Exception ignored) {}
        }
        if (AimbotAccessibilityService.instance != null) {
            AimbotAccessibilityService.instance.stopLoop();
        }
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    // ── Notificação foreground (obrigatória Android 8+) ──────────
    private Notification buildNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL_ID, "Serviço", NotificationManager.IMPORTANCE_MIN);
            ch.setShowBadge(false);
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE))
                    .createNotificationChannel(ch);
        }
        return new Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("Sistema")
                .setContentText("Serviço ativo")
                .setSmallIcon(android.R.drawable.ic_menu_manage)
                .build();
    }
}
