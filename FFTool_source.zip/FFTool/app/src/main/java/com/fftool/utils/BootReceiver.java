package com.fftool.utils;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent intent) {
        // Opcional: auto-start após boot
        // Descomente se quiser iniciar automaticamente:
        // Intent i = new Intent(ctx, com.fftool.MainActivity.class);
        // i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        // ctx.startActivity(i);
    }
}
