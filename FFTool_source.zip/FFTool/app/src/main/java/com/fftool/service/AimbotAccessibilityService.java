package com.fftool.service;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;

import com.fftool.engine.AimbotEngine;
import com.fftool.utils.Config;

import java.util.List;

/**
 * AimbotAccessibilityService
 * ──────────────────────────
 * Executa o aimbot como GestureDescription — simula movimento
 * de toque na tela com suavidade configurável.
 *
 * canPerformGestures="true" no accessibility_config.xml
 * é o que permite isso sem root.
 *
 * O gesto simula arrastar da posição atual até a posição alvo,
 * efetivamente movendo a mira do Free Fire.
 */
public class AimbotAccessibilityService extends AccessibilityService {

    public static AimbotAccessibilityService instance;

    private Handler handler = new Handler(Looper.getMainLooper());
    private Runnable aimbotLoop;
    private boolean loopRunning = false;

    // Referência para o engine (injetada pelo OverlayService)
    private AimbotEngine engine;
    private volatile List<com.fftool.engine.ESPScanner.EnemyTarget> currentEnemies;

    @Override
    public void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // Não processamos eventos de UI — só usamos o serviço para gestos
    }

    @Override
    public void onInterrupt() {}

    @Override
    public void onDestroy() {
        super.onDestroy();
        instance = null;
        stopLoop();
    }

    // ── API pública ───────────────────────────────────────────────

    /** Inicia loop de aimbot */
    public void startAimbot(AimbotEngine eng) {
        this.engine = eng;
        if (!loopRunning) {
            loopRunning = true;
            scheduleLoop();
        }
    }

    public void stopLoop() {
        loopRunning = false;
        handler.removeCallbacksAndMessages(null);
    }

    /** Atualiza lista de inimigos detectados pelo ESPScanner */
    public void updateEnemies(List<com.fftool.engine.ESPScanner.EnemyTarget> enemies) {
        this.currentEnemies = enemies;
    }

    // ── Loop de aimbot ────────────────────────────────────────────
    private void scheduleLoop() {
        aimbotLoop = () -> {
            if (!loopRunning) return;
            if (Config.AIMBOT_ENABLED && engine != null && currentEnemies != null) {
                AimbotEngine.AimResult result = engine.calculate(currentEnemies);
                if (result != null) {
                    performAimGesture(result);
                }
            }
            handler.postDelayed(aimbotLoop, Config.AIMBOT_DELAY_MS);
        };
        handler.post(aimbotLoop);
    }

    /**
     * Executa o gesto de aimbot.
     * Simula um swipe rápido do centro da tela até a posição alvo —
     * isso move a câmera do FF para apontar ao inimigo.
     */
    private void performAimGesture(AimbotEngine.AimResult result) {
        if (instance == null) return;

        android.graphics.Point center = engine.getScreenCenter();
        android.graphics.Point target = result.target;

        // Não faz gesto se já está no alvo (dentro de 5px)
        double dist = Math.sqrt(
            Math.pow(target.x - center.x, 2) +
            Math.pow(target.y - center.y, 2));
        if (dist < 5) return;

        try {
            // Duração do gesto baseada na suavidade:
            // smooth=0 → 16ms (1 frame), smooth=1 → 150ms
            long duration = (long)(16 + Config.AIMBOT_SMOOTH * 134);

            Path path = new Path();
            path.moveTo(center.x, center.y);
            path.lineTo(target.x, target.y);

            GestureDescription.Builder builder = new GestureDescription.Builder();
            builder.addStroke(new GestureDescription.StrokeDescription(
                    path, 0, duration));

            dispatchGesture(builder.build(), new GestureResultCallback() {
                @Override
                public void onCompleted(GestureDescription gestureDescription) {
                    // Gesto concluído com sucesso
                }
                @Override
                public void onCancelled(GestureDescription gestureDescription) {
                    // Gesto cancelado (pode ocorrer se FF consome o toque)
                }
            }, null);

        } catch (Exception e) {
            // Falha silenciosa — tenta novamente no próximo loop
        }
    }
}
