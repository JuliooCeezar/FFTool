package com.fftool.overlay;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.os.Build;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import com.fftool.utils.Config;

/**
 * FloatingButton
 * ──────────────
 * Botão flutuante sempre visível por cima do jogo.
 * Toque simples: liga/desliga ESP+Aimbot juntos.
 * Toque longo: abre mini-painel de configuração.
 *
 * Painel de configuração inclui:
 *  - Toggle ESP
 *  - Toggle Aimbot
 *  - Slider FOV
 *  - Slider Smooth
 *  - Selector de osso alvo
 */
public class FloatingButton {

    private Context ctx;
    private WindowManager wm;

    // Views
    private View      btnView;
    private View      panelView;
    private boolean   panelOpen = false;

    // Drag state
    private int lastX, lastY;
    private boolean dragging = false;

    private WindowManager.LayoutParams btnParams;
    private WindowManager.LayoutParams panelParams;

    // Listener para notificar OverlayService
    public interface ToggleListener {
        void onToggle(boolean espOn, boolean aimOn);
    }
    private ToggleListener toggleListener;

    public FloatingButton(Context ctx, WindowManager wm, ToggleListener l) {
        this.ctx = ctx;
        this.wm = wm;
        this.toggleListener = l;
        buildButton();
        buildPanel();
    }

    // ── Botão principal ──────────────────────────────────────────
    private void buildButton() {
        btnView = new View(ctx) {
            private Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            private Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);

            {
                tp.setColor(Color.WHITE);
                tp.setTextSize(18f);
                tp.setTextAlign(Paint.Align.CENTER);
            }

            @Override
            protected void onDraw(Canvas c) {
                float r = getWidth() / 2f;
                // Fundo
                p.setColor(isActive() ? Color.argb(200, 0, 180, 0)
                                      : Color.argb(200, 180, 0, 0));
                c.drawCircle(r, r, r - 2, p);
                // Borda
                p.setStyle(Paint.Style.STROKE);
                p.setColor(Color.WHITE);
                p.setStrokeWidth(2f);
                c.drawCircle(r, r, r - 2, p);
                p.setStyle(Paint.Style.FILL);
                // Texto
                String txt = isActive() ? "ON" : "OFF";
                c.drawText(txt, r, r + tp.getTextSize() / 3, tp);
            }

            private boolean isActive() {
                return Config.ESP_ENABLED || Config.AIMBOT_ENABLED;
            }
        };

        int size = dp(60);
        btnParams = makeParams(size, size, Config.FLOAT_BTN_X, Config.FLOAT_BTN_Y);

        btnView.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    lastX = (int) event.getRawX();
                    lastY = (int) event.getRawY();
                    dragging = false;
                    return true;

                case MotionEvent.ACTION_MOVE:
                    int dx = (int) event.getRawX() - lastX;
                    int dy = (int) event.getRawY() - lastY;
                    if (Math.abs(dx) > 5 || Math.abs(dy) > 5) {
                        dragging = true;
                        btnParams.x += dx;
                        btnParams.y += dy;
                        Config.FLOAT_BTN_X = btnParams.x;
                        Config.FLOAT_BTN_Y = btnParams.y;
                        wm.updateViewLayout(btnView, btnParams);
                    }
                    lastX = (int) event.getRawX();
                    lastY = (int) event.getRawY();
                    return true;

                case MotionEvent.ACTION_UP:
                    if (!dragging) {
                        // Toggle
                        boolean newState = !(Config.ESP_ENABLED || Config.AIMBOT_ENABLED);
                        Config.ESP_ENABLED    = newState;
                        Config.AIMBOT_ENABLED = newState;
                        btnView.invalidate();
                        if (toggleListener != null)
                            toggleListener.onToggle(Config.ESP_ENABLED, Config.AIMBOT_ENABLED);
                    }
                    return true;
            }
            return false;
        });

        btnView.setOnLongClickListener(v -> {
            togglePanel();
            return true;
        });
    }

    // ── Painel de configuração ───────────────────────────────────
    private void buildPanel() {
        LinearLayout panel = new LinearLayout(ctx);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackgroundColor(Color.argb(220, 20, 20, 20));
        panel.setPadding(dp(12), dp(12), dp(12), dp(12));

        // Título
        addLabel(panel, "⚙ FFTool Config", 18f, Color.WHITE);
        addDivider(panel);

        // Toggle ESP
        addToggleRow(panel, "ESP Wallhack",
                Config.ESP_ENABLED,
                val -> { Config.ESP_ENABLED = val; });

        // Toggle Aimbot
        addToggleRow(panel, "Aimbot",
                Config.AIMBOT_ENABLED,
                val -> { Config.AIMBOT_ENABLED = val; });

        addDivider(panel);

        // FOV Slider
        addLabel(panel, "FOV Aimbot: " + Config.AIMBOT_FOV, 14f, Color.LTGRAY);
        SeekBar fovBar = new SeekBar(ctx);
        fovBar.setMax(400);
        fovBar.setProgress(Config.AIMBOT_FOV);
        fovBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean u) {
                Config.AIMBOT_FOV = Math.max(10, p);
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });
        panel.addView(fovBar);

        // Smooth Slider
        addLabel(panel, "Smooth Aimbot", 14f, Color.LTGRAY);
        SeekBar smoothBar = new SeekBar(ctx);
        smoothBar.setMax(100);
        smoothBar.setProgress((int)(Config.AIMBOT_SMOOTH * 100));
        smoothBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean u) {
                Config.AIMBOT_SMOOTH = p / 100f;
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });
        panel.addView(smoothBar);

        addDivider(panel);

        // Osso alvo
        addLabel(panel, "Alvo:", 14f, Color.LTGRAY);
        LinearLayout boneRow = new LinearLayout(ctx);
        boneRow.setOrientation(LinearLayout.HORIZONTAL);
        String[] bones = {"Cabeça", "Pescoço", "Tórax"};
        for (int i = 0; i < bones.length; i++) {
            final int idx = i;
            TextView tv = new TextView(ctx);
            tv.setText(bones[i]);
            tv.setPadding(dp(8), dp(4), dp(8), dp(4));
            tv.setTextColor(Color.WHITE);
            tv.setBackgroundColor(Config.AIMBOT_TARGET_BONE == idx
                    ? Color.argb(200, 0, 120, 0) : Color.argb(100, 60, 60, 60));
            tv.setOnClickListener(v -> {
                Config.AIMBOT_TARGET_BONE = idx;
                // Rebuild panel para atualizar highlight
                // (simplificado — atualiza na próxima abertura)
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            lp.setMargins(dp(2), 0, dp(2), 0);
            boneRow.addView(tv, lp);
        }
        panel.addView(boneRow);

        addDivider(panel);

        // Fechar painel
        TextView closeBtn = new TextView(ctx);
        closeBtn.setText("✕ Fechar");
        closeBtn.setTextColor(Color.argb(220, 255, 80, 80));
        closeBtn.setTextSize(14f);
        closeBtn.setPadding(dp(4), dp(4), dp(4), dp(4));
        closeBtn.setOnClickListener(v -> togglePanel());
        panel.addView(closeBtn);

        panelView = panel;
        panelParams = makeParams(
                dp(260),
                WindowManager.LayoutParams.WRAP_CONTENT,
                Config.FLOAT_BTN_X + dp(65),
                Config.FLOAT_BTN_Y);
    }

    private void togglePanel() {
        if (panelOpen) {
            wm.removeView(panelView);
            panelOpen = false;
        } else {
            panelParams.x = Config.FLOAT_BTN_X + dp(65);
            panelParams.y = Config.FLOAT_BTN_Y;
            wm.addView(panelView, panelParams);
            panelOpen = true;
        }
    }

    // ── Helpers de UI ────────────────────────────────────────────
    private interface BoolConsumer { void accept(boolean v); }

    private void addToggleRow(LinearLayout parent, String label,
                               boolean initial, BoolConsumer onChange) {
        LinearLayout row = new LinearLayout(ctx);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(4), 0, dp(4));

        TextView lbl = new TextView(ctx);
        lbl.setText(label);
        lbl.setTextColor(Color.WHITE);
        lbl.setTextSize(14f);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lbl.setLayoutParams(lp);
        row.addView(lbl);

        android.widget.Switch sw = new android.widget.Switch(ctx);
        sw.setChecked(initial);
        sw.setOnCheckedChangeListener((btn, val) -> onChange.accept(val));
        row.addView(sw);

        parent.addView(row);
    }

    private void addLabel(LinearLayout p, String text, float size, int color) {
        TextView tv = new TextView(ctx);
        tv.setText(text);
        tv.setTextColor(color);
        tv.setTextSize(size);
        p.addView(tv);
    }

    private void addDivider(LinearLayout p) {
        View d = new View(ctx);
        d.setBackgroundColor(Color.argb(80, 255, 255, 255));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 1);
        lp.setMargins(0, dp(6), 0, dp(6));
        p.addView(d, lp);
    }

    private int dp(int dp) {
        return (int)(dp * ctx.getResources().getDisplayMetrics().density);
    }

    private WindowManager.LayoutParams makeParams(int w, int h, int x, int y) {
        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                w, h, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.LEFT;
        p.x = x;
        p.y = y;
        return p;
    }

    // ── Adiciona ao WindowManager ─────────────────────────────────
    public void attach() {
        wm.addView(btnView, btnParams);
    }

    public void detach() {
        try { wm.removeView(btnView); } catch (Exception ignored) {}
        if (panelOpen) {
            try { wm.removeView(panelView); } catch (Exception ignored) {}
        }
    }
}
