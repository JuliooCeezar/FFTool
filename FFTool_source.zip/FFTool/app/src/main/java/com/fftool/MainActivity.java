package com.fftool;

import android.app.Activity;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Toast;
import com.fftool.service.OverlayService;
import com.fftool.utils.PermissionHelper;

public class MainActivity extends Activity {

    private static final int REQ_OVERLAY   = 1001;
    private static final int REQ_PROJECTION = 1002;

    private MediaProjectionManager mpm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);

        // Passo 1: overlay
        if (!Settings.canDrawOverlays(this)) {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivityForResult(i, REQ_OVERLAY);
        } else {
            requestProjection();
        }
    }

    private void requestProjection() {
        // Passo 2: captura de tela para ESP
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_PROJECTION);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);

        if (req == REQ_OVERLAY) {
            if (Settings.canDrawOverlays(this)) {
                requestProjection();
            } else {
                Toast.makeText(this, "Permissão overlay necessária", Toast.LENGTH_LONG).show();
                finish();
            }
            return;
        }

        if (req == REQ_PROJECTION) {
            if (res == RESULT_OK) {
                // Passa resultado do MediaProjection para o serviço
                Intent svc = new Intent(this, OverlayService.class);
                svc.putExtra("resultCode", res);
                svc.putExtra("data", data);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    startForegroundService(svc);
                } else {
                    startService(svc);
                }
                Toast.makeText(this, "✓ FFTool ativo — botão flutuante na tela", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Captura negada — ESP desativado", Toast.LENGTH_LONG).show();
            }
            finish();
        }
    }
}
