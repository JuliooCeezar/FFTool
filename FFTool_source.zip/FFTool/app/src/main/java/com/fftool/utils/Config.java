package com.fftool.utils;

import android.graphics.Color;

/**
 * Config central — todos os parâmetros ajustáveis do FFTool.
 * Modifique aqui ou pelo overlay de configuração em runtime.
 */
public final class Config {

    // ── Pacote alvo ──────────────────────────────────────────────
    public static final String FF_PACKAGE = "com.dts.freefireth";

    // ── Toggles globais ──────────────────────────────────────────
    public static volatile boolean ESP_ENABLED    = true;
    public static volatile boolean AIMBOT_ENABLED = true;

    // ── ESP ──────────────────────────────────────────────────────
    /** Cor da caixa ESP padrão (vermelho) */
    public static volatile int ESP_COLOR_DEFAULT  = Color.RED;
    /** Cor quando inimigo é o alvo do aimbot (amarelo) */
    public static volatile int ESP_COLOR_LOCKED   = Color.YELLOW;
    /** Espessura da linha da caixa */
    public static volatile float ESP_LINE_WIDTH   = 2.5f;
    /** Mostrar barra de HP */
    public static volatile boolean ESP_SHOW_HP    = true;
    /** Mostrar distância em metros */
    public static volatile boolean ESP_SHOW_DIST  = true;
    /** Mostrar nome/tag */
    public static volatile boolean ESP_SHOW_NAME  = false;
    /** ESP wallhack — desenha através de paredes */
    public static volatile boolean ESP_WALLHACK   = true;

    // ── Aimbot ───────────────────────────────────────────────────
    /** FOV em pixels de raio ao redor do centro da tela */
    public static volatile int AIMBOT_FOV         = 180;
    /** Suavidade do movimento (0.0 = instantâneo, 1.0 = muito suave) */
    public static volatile float AIMBOT_SMOOTH    = 0.35f;
    /** Alvo: 0 = cabeça, 1 = pescoço, 2 = tórax */
    public static volatile int AIMBOT_TARGET_BONE = 0;
    /** Aimbot ativo apenas enquanto botão de atirar estiver pressionado */
    public static volatile boolean AIMBOT_TRIGGERBOT = false;
    /** Delay entre gestos de aimbot em ms */
    public static volatile long AIMBOT_DELAY_MS   = 16L; // ~60fps

    // ── Detecção de cor (ESP via pixel) ─────────────────────────
    /**
     * Free Fire — cor do contorno de inimigo renderizado pelo engine.
     * Branco/cinza claro na silhueta quando visível.
     * Usado pelo ESPScanner para localizar caixas via MediaProjection.
     */
    public static final int ENEMY_OUTLINE_COLOR   = Color.rgb(220, 220, 220);
    public static final int COLOR_TOLERANCE       = 30;

    // ── Resolução de referência (escala automática) ───────────────
    public static final int REF_WIDTH  = 1280;
    public static final int REF_HEIGHT = 720;

    // ── Configuração de overlay ───────────────────────────────────
    /** Posição inicial do botão flutuante (X, Y) */
    public static int FLOAT_BTN_X = 20;
    public static int FLOAT_BTN_Y = 300;

    private Config() {}
}
