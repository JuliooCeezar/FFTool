package com.fftool.utils;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;

public class PermissionHelper {

    public static boolean hasOverlay(Context ctx) {
        return Settings.canDrawOverlays(ctx);
    }

    public static Intent overlayIntent(Context ctx) {
        return new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + ctx.getPackageName()));
    }

    public static boolean isAccessibilityEnabled(Context ctx, Class<?> svc) {
        android.view.accessibility.AccessibilityManager am =
                (android.view.accessibility.AccessibilityManager)
                ctx.getSystemService(Context.ACCESSIBILITY_SERVICE);
        java.util.List<android.accessibilityservice.AccessibilityServiceInfo> list =
                am.getEnabledAccessibilityServiceList(
                android.accessibilityservice.AccessibilityServiceInfo.FEEDBACK_GENERIC);
        for (android.accessibilityservice.AccessibilityServiceInfo info : list) {
            if (info.getResolveInfo().serviceInfo.packageName.equals(ctx.getPackageName())) {
                return true;
            }
        }
        return false;
    }

    public static Intent accessibilityIntent() {
        return new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
    }
}
