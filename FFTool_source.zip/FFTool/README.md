# FFTool — Free Fire ESP + Aimbot (Android)

## Arquitetura

```
FFTool/
├── MainActivity.java          → Setup de permissões
├── engine/
│   ├── ESPScanner.java        → Captura tela + detecção de inimigos por cor
│   └── AimbotEngine.java      → Cálculo de alvo + suavidade
├── overlay/
│   ├── ESPRenderer.java       → Overlay transparente com caixas ESP
│   └── FloatingButton.java    → Botão on/off + painel de config
├── service/
│   ├── OverlayService.java    → Orquestrador principal (foreground service)
│   └── AimbotAccessibilityService.java → Gestos de aimbot
└── utils/
    ├── Config.java            → Todos os parâmetros configuráveis
    ├── PermissionHelper.java
    └── BootReceiver.java
```

## Como Compilar (Android Studio)

1. Abra o Android Studio
2. File → Open → selecione a pasta `FFTool/`
3. Aguarde sync do Gradle
4. Build → Build Bundle(s)/APK(s) → Build APK(s)
5. APK gerado em: `app/build/outputs/apk/debug/app-debug.apk`

## Como Compilar (linha de comando)

```bash
# Windows
gradlew.bat assembleDebug

# Linux/Mac
./gradlew assembleDebug
```

## Instalação no Celular

```bash
adb install app/build/outputs/apk/debug/app-debug.apk
```

Ou transfira o APK para o celular e instale (habilite "Fontes desconhecidas").

## Configuração no Celular

1. **Instale o APK**
2. **Abra o app** → vai pedir:
   - Permissão de overlay → Permitir
   - Captura de tela → Permitir (para ESP)
3. **Habilite o Serviço de Acessibilidade:**
   - Configurações → Acessibilidade → FFTool (Sistema) → Ativar
   - ⚠️ Necessário para o aimbot funcionar
4. **Abra o Free Fire**
5. O botão flutuante aparece na tela

## Controles

| Ação              | Como fazer                         |
|-------------------|------------------------------------|
| ON/OFF tudo       | Toque no botão flutuante           |
| Abrir config      | Toque longo no botão flutuante     |
| Mover botão       | Arraste o botão                    |
| FOV aimbot        | Painel config → slider FOV         |
| Suavidade aimbot  | Painel config → slider Smooth      |
| Alvo (cabeça etc.)| Painel config → Cabeça/Pescoço/Tórax|
| Toggle ESP só     | Painel config → switch ESP         |
| Toggle Aimbot só  | Painel config → switch Aimbot      |

## Ajuste Fino da Detecção (Config.java)

```java
// Cor do contorno de inimigo — calibre para sua tela
ENEMY_OUTLINE_COLOR = Color.rgb(220, 220, 220);
COLOR_TOLERANCE     = 30;   // aumenta se perder inimigos, diminui se pegar FP

// Aimbot
AIMBOT_FOV          = 180;  // raio em pixels
AIMBOT_SMOOTH       = 0.35f; // 0.0 = snap, 1.0 = muito suave
AIMBOT_TARGET_BONE  = 0;    // 0=cabeça, 1=pescoço, 2=tórax
AIMBOT_DELAY_MS     = 16L;  // ms entre frames do aimbot (~60fps)
```

## Notas Técnicas

- **ESP Wallhack:** funciona via análise de pixel do frame capturado pelo
  MediaProjection. Free Fire renderiza silhuetas de inimigos que ficam
  visíveis na captura mesmo quando atrás de paredes em alguns cenários.
  
- **Aimbot:** usa GestureDescription da API de Acessibilidade para simular
  swipe na tela — move a câmera do jogo. Não requer root.

- **Sem root necessário:** tudo via APIs públicas Android (overlay,
  MediaProjection, AccessibilityService).

- **Compatibilidade:** Android 8.0+ (API 26+). Testado até Android 13.

## Requisitos

- Android 8.0 ou superior
- Free Fire versão Brasil (com.dts.freefireth)
- Permissão overlay ativa
- Serviço de acessibilidade ativo
