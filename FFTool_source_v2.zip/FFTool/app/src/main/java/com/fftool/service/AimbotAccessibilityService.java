package com.fftool.service;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;

import com.fftool.engine.AimbotEngine;
import com.fftool.engine.RapidFireEngine;
import com.fftool.engine.SpeedEngine;
import com.fftool.utils.Config;

import java.util.List;

/**
 * AimbotAccessibilityService
 * ──────────────────────────
 * Serviço de acessibilidade central — executa todos os gestos:
 *  - Aimbot (mira automática)
 *  - RapidFire (velocidade de tiro)
 *  - Speed (velocidade do personagem)
 */
public class AimbotAccessibilityService extends AccessibilityService {

    public static AimbotAccessibilityService instance;

    private Handler handler = new Handler(Looper.getMainLooper());
    private Runnable aimbotLoop;
    private boolean loopRunning = false;

    private AimbotEngine    engine;
    private RapidFireEngine rapidFire;
    private SpeedEngine     speed;

    private volatile List<com.fftool.engine.ESPScanner.EnemyTarget> currentEnemies;

    @Override
    public void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {}

    @Override
    public void onInterrupt() {}

    @Override
    public void onDestroy() {
        super.onDestroy();
        instance = null;
        stopLoop();
        if (rapidFire != null) rapidFire.stop();
        if (speed     != null) speed.stop();
    }

    // ── API pública ───────────────────────────────────────────────

    public void startAimbot(AimbotEngine eng) {
        this.engine = eng;
        if (!loopRunning) {
            loopRunning = true;
            scheduleLoop();
        }
    }

    public void stopLoop() {
        loopRunning = false;
        handler.removeCallbacksAndMessages(null);
    }

    public void updateEnemies(List<com.fftool.engine.ESPScanner.EnemyTarget> enemies) {
        this.currentEnemies = enemies;
    }

    // ── RapidFire ─────────────────────────────────────────────────

    public void startRapidFire(android.view.WindowManager wm) {
        if (rapidFire == null) {
            rapidFire = new RapidFireEngine(this, wm);
        }
        if (!rapidFire.isRunning()) rapidFire.start();
    }

    public void stopRapidFire() {
        if (rapidFire != null) rapidFire.stop();
    }

    // ── Speed ─────────────────────────────────────────────────────

    public void startSpeed(android.view.WindowManager wm) {
        if (speed == null) {
            speed = new SpeedEngine(this, wm);
        }
        if (!speed.isRunning()) speed.start();
    }

    public void stopSpeed() {
        if (speed != null) speed.stop();
    }

    public SpeedEngine getSpeedEngine() { return speed; }

    // ── Loop de aimbot ────────────────────────────────────────────

    private void scheduleLoop() {
        aimbotLoop = () -> {
            if (!loopRunning) return;
            if (Config.AIMBOT_ENABLED && engine != null && currentEnemies != null) {
                AimbotEngine.AimResult result = engine.calculate(currentEnemies);
                if (result != null) {
                    performAimGesture(result);
                }
            }
            handler.postDelayed(aimbotLoop, Config.AIMBOT_DELAY_MS);
        };
        handler.post(aimbotLoop);
    }

    private void performAimGesture(AimbotEngine.AimResult result) {
        if (instance == null) return;

        android.graphics.Point center = engine.getScreenCenter();
        android.graphics.Point target = result.target;

        double dist = Math.sqrt(
            Math.pow(target.x - center.x, 2) +
            Math.pow(target.y - center.y, 2));
        if (dist < 5) return;

        try {
            long duration = (long)(16 + Config.AIMBOT_SMOOTH * 134);

            Path path = new Path();
            path.moveTo(center.x, center.y);
            path.lineTo(target.x, target.y);

            GestureDescription.Builder builder = new GestureDescription.Builder();
            builder.addStroke(new GestureDescription.StrokeDescription(
                    path, 0, duration));

            dispatchGesture(builder.build(), new GestureResultCallback() {
                @Override public void onCompleted(GestureDescription g) {}
                @Override public void onCancelled(GestureDescription g) {}
            }, null);

        } catch (Exception ignored) {}
    }
}
