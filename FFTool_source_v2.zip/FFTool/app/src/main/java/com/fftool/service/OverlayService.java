package com.fftool.service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.IBinder;
import android.view.WindowManager;

import com.fftool.engine.AimbotEngine;
import com.fftool.engine.ESPScanner;
import com.fftool.overlay.ESPRenderer;
import com.fftool.overlay.FloatingButton;
import com.fftool.utils.AntiDetect;
import com.fftool.utils.Config;

/**
 * OverlayService
 * ──────────────
 * Orquestra todos os módulos:
 *  ESP + Aimbot + RapidFire + Speed + AntiDetect
 */
public class OverlayService extends Service {

    private static final String CHANNEL_ID = "fftool_fg";
    private static final int    NOTIF_ID   = 1;

    private WindowManager   wm;
    private MediaProjection mp;
    private ESPScanner      scanner;
    private ESPRenderer     espRenderer;
    private AimbotEngine    aimbotEngine;
    private FloatingButton  floatBtn;
    private AntiDetect      antiDetect;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground(NOTIF_ID, buildNotification());

        int resultCode = intent.getIntExtra("resultCode", -1);
        Intent data    = intent.getParcelableExtra("data");

        wm = (WindowManager) getSystemService(WINDOW_SERVICE);

        MediaProjectionManager mpm =
                (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        mp = mpm.getMediaProjection(resultCode, data);

        aimbotEngine = new AimbotEngine(wm);

        // ── Anti-detecção ─────────────────────────────────────────
        antiDetect = new AntiDetect(this, new AntiDetect.PauseCallback() {
            @Override
            public void onPause() {
                // Anti-cheat detectado — pausa tudo
                Config.ESP_ENABLED    = false;
                Config.AIMBOT_ENABLED = false;
                Config.RAPID_FIRE_ENABLED = false;
                Config.SPEED_ENABLED  = false;
            }
            @Override
            public void onResume() {
                // Anti-cheat sumiu — retoma estado anterior
                // (usuário pode ligar manualmente no painel)
            }
        });
        antiDetect.start();

        // ── ESP Renderer ──────────────────────────────────────────
        espRenderer = new ESPRenderer(this, aimbotEngine);
        wm.addView(espRenderer, ESPRenderer.buildLayoutParams());

        // ── Scanner ───────────────────────────────────────────────
        scanner = new ESPScanner(mp, wm, enemies -> {
            // Throttle de CPU em background
            if (Config.ANTI_DETECT_ENABLED && Config.ANTI_DETECT_BG_THROTTLE
                    && !antiDetect.isFFInForeground()) {
                return; // não escaneia quando FF não está em foco
            }

            espRenderer.updateEnemies(enemies);

            if (AimbotAccessibilityService.instance != null) {
                AimbotAccessibilityService.instance.updateEnemies(enemies);
            }
        });
        scanner.start();

        // ── Aimbot ────────────────────────────────────────────────
        if (AimbotAccessibilityService.instance != null) {
            AimbotAccessibilityService.instance.startAimbot(aimbotEngine);
        }

        // ── Botão flutuante ───────────────────────────────────────
        floatBtn = new FloatingButton(this, wm, (espOn, aimOn, rapidOn, speedOn) -> {
            // Aimbot
            if (!aimOn && AimbotAccessibilityService.instance != null) {
                AimbotAccessibilityService.instance.stopLoop();
            } else if (aimOn && AimbotAccessibilityService.instance != null) {
                AimbotAccessibilityService.instance.startAimbot(aimbotEngine);
            }

            // RapidFire
            if (AimbotAccessibilityService.instance != null) {
                if (rapidOn) {
                    AimbotAccessibilityService.instance.startRapidFire(wm);
                } else {
                    AimbotAccessibilityService.instance.stopRapidFire();
                }
            }

            // Speed
            if (AimbotAccessibilityService.instance != null) {
                if (speedOn) {
                    AimbotAccessibilityService.instance.startSpeed(wm);
                } else {
                    AimbotAccessibilityService.instance.stopSpeed();
                }
            }
        });
        floatBtn.attach();

        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (antiDetect   != null) antiDetect.stop();
        if (scanner      != null) scanner.stop();
        if (floatBtn     != null) floatBtn.detach();
        if (espRenderer  != null) {
            try { wm.removeView(espRenderer); } catch (Exception ignored) {}
        }
        if (AimbotAccessibilityService.instance != null) {
            AimbotAccessibilityService.instance.stopLoop();
            AimbotAccessibilityService.instance.stopRapidFire();
            AimbotAccessibilityService.instance.stopSpeed();
        }
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    private Notification buildNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL_ID, "Serviço", NotificationManager.IMPORTANCE_MIN);
            ch.setShowBadge(false);
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE))
                    .createNotificationChannel(ch);
        }
        return new Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("Sistema")
                .setContentText("Serviço ativo")
                .setSmallIcon(android.R.drawable.ic_menu_manage)
                .build();
    }
}
