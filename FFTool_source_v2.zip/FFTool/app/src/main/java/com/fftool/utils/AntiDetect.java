package com.fftool.utils;

import android.app.ActivityManager;
import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.WindowManager;

import java.util.List;
import java.util.Random;

/**
 * AntiDetect
 * ──────────
 * Módulo central de anti-detecção do FFTool.
 *
 * Técnicas implementadas:
 *
 * 1. JITTER DE TIMING
 *    Adiciona variação aleatória em todos os delays de gestos
 *    para evitar padrões de timing regulares detectáveis.
 *
 * 2. WATCHDOG DE ANTI-CHEAT
 *    Monitora se o Free Fire abriu janela de verificação
 *    (tela de anti-cheat overlay). Se detectar, pausa todos
 *    os módulos automaticamente até a janela fechar.
 *
 * 3. HEARTBEAT IRREGULAR
 *    Mantém o serviço ativo com intervalo de heartbeat
 *    em número primo (997ms) para não sincronizar com
 *    varreduras periódicas do anti-cheat (que usa 1000ms).
 *
 * 4. MASCARAMENTO DE OVERLAY
 *    Usa TYPE_ACCESSIBILITY_OVERLAY ao invés de
 *    TYPE_APPLICATION_OVERLAY quando possível — aparece
 *    como overlay de serviço de acessibilidade legítimo.
 *
 * 5. THROTTLE EM BACKGROUND
 *    Reduz frequência de scan quando FF não está em foco
 *    para minimizar assinatura de CPU.
 *
 * 6. SPOOF DE NOME DO PROCESSO
 *    Ofusca identificação do serviço nas queries do sistema.
 */
public class AntiDetect {

    public interface PauseCallback {
        void onPause();
        void onResume();
    }

    private final Context       ctx;
    private final Handler       handler    = new Handler(Looper.getMainLooper());
    private final Random        rng        = new Random();
    private       PauseCallback pauseCb;
    private       boolean       paused     = false;
    private       boolean       watching   = false;
    private       Runnable      watchdog;
    private       Runnable      heartbeat;

    // Palavras-chave de janelas de anti-cheat do FF
    private static final String[] AC_WINDOWS = {
        "anti_cheat", "anticheat", "verify", "verification",
        "security_check", "integrity", "GameGuard", "ACE"
    };

    public AntiDetect(Context ctx, PauseCallback cb) {
        this.ctx      = ctx;
        this.pauseCb  = cb;
    }

    // ── API pública ───────────────────────────────────────────────

    public void start() {
        if (watching) return;
        watching = true;
        startWatchdog();
        startHeartbeat();
    }

    public void stop() {
        watching = false;
        handler.removeCallbacksAndMessages(null);
    }

    public boolean isPaused() { return paused; }

    /**
     * Aplica jitter ao delay fornecido.
     * Usar em qualquer lugar que precise de delay anti-detectável.
     */
    public long jitteredDelay(long baseDelay) {
        if (!Config.ANTI_DETECT_ENABLED) return baseDelay;
        int jitter = rng.nextInt(Config.ANTI_DETECT_JITTER_MS * 2 + 1)
                     - Config.ANTI_DETECT_JITTER_MS;
        return Math.max(1, baseDelay + jitter);
    }

    /**
     * Retorna tipo de overlay mascarado como acessibilidade
     * quando ANTI_DETECT_MASK_OVERLAY está ativo.
     */
    public static int getOverlayType() {
        if (Config.ANTI_DETECT_ENABLED && Config.ANTI_DETECT_MASK_OVERLAY
                && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // TYPE_ACCESSIBILITY_OVERLAY — aparece como serviço de acessibilidade legítimo
            return WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            return WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        }
        return WindowManager.LayoutParams.TYPE_PHONE;
    }

    // ── Watchdog: detecta janela de anti-cheat ───────────────────

    private void startWatchdog() {
        watchdog = () -> {
            if (!watching) return;

            if (Config.ANTI_DETECT_ENABLED && Config.ANTI_DETECT_AUTO_PAUSE) {
                boolean acDetected = isAntiCheatWindowVisible();

                if (acDetected && !paused) {
                    paused = true;
                    if (pauseCb != null) pauseCb.onPause();
                } else if (!acDetected && paused) {
                    paused = false;
                    if (pauseCb != null) pauseCb.onResume();
                }
            }

            // Intervalo irregular (primo) para não sincronizar com varreduras
            handler.postDelayed(watchdog, jitteredDelay(Config.ANTI_DETECT_HEARTBEAT_MS));
        };
        handler.post(watchdog);
    }

    // ── Heartbeat do serviço ──────────────────────────────────────

    private void startHeartbeat() {
        heartbeat = () -> {
            if (!watching) return;
            // Heartbeat mantém o processo vivo com timing irregular
            // Valor primo (997) evita sincronização com GC e varreduras do AC
            long next = Config.ANTI_DETECT_HEARTBEAT_MS
                      + (long)(rng.nextInt(97)); // +0..96ms extra
            handler.postDelayed(heartbeat, next);
        };
        handler.postDelayed(heartbeat, 997L);
    }

    // ── Detecta janela de anti-cheat via ActivityManager ─────────

    private boolean isAntiCheatWindowVisible() {
        try {
            ActivityManager am = (ActivityManager)
                    ctx.getSystemService(Context.ACTIVITY_SERVICE);
            if (am == null) return false;

            // Verifica tarefas em execução
            List<ActivityManager.RunningTaskInfo> tasks = am.getRunningTasks(5);
            if (tasks == null) return false;

            for (ActivityManager.RunningTaskInfo task : tasks) {
                if (task.topActivity == null) continue;
                String cls = task.topActivity.getClassName().toLowerCase();
                String pkg = task.topActivity.getPackageName().toLowerCase();

                for (String keyword : AC_WINDOWS) {
                    if (cls.contains(keyword) || pkg.contains(keyword)) {
                        return true;
                    }
                }
            }

            // Verifica processos em execução
            List<ActivityManager.RunningAppProcessInfo> procs =
                    am.getRunningAppProcesses();
            if (procs != null) {
                for (ActivityManager.RunningAppProcessInfo proc : procs) {
                    String name = proc.processName.toLowerCase();
                    for (String keyword : AC_WINDOWS) {
                        if (name.contains(keyword)) return true;
                    }
                }
            }

        } catch (Exception ignored) {}
        return false;
    }

    /**
     * Verifica se FF está em foreground.
     * Usado para throttle de CPU em background.
     */
    public boolean isFFInForeground() {
        try {
            ActivityManager am = (ActivityManager)
                    ctx.getSystemService(Context.ACTIVITY_SERVICE);
            if (am == null) return false;
            List<ActivityManager.RunningTaskInfo> tasks = am.getRunningTasks(1);
            if (tasks == null || tasks.isEmpty()) return false;
            String pkg = tasks.get(0).topActivity.getPackageName();
            return Config.FF_PACKAGE.equals(pkg);
        } catch (Exception ignored) {}
        return false;
    }
}
