package com.fftool.overlay;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.os.Build;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

import com.fftool.utils.AntiDetect;
import com.fftool.utils.Config;

/**
 * FloatingButton
 * ──────────────
 * Botão flutuante + painel completo de configuração.
 *
 * Painel organizado em abas/seções:
 *  ① ESP
 *  ② Aimbot
 *  ③ Velocidade de Tiro (RapidFire)
 *  ④ Velocidade do Personagem (Speed)
 *  ⑤ Anti-Detecção
 */
public class FloatingButton {

    public interface ToggleListener {
        void onToggle(boolean espOn, boolean aimOn, boolean rapidOn, boolean speedOn);
    }

    private Context        ctx;
    private WindowManager  wm;
    private ToggleListener toggleListener;

    private View    btnView;
    private View    panelView;
    private boolean panelOpen = false;

    private int lastX, lastY;
    private boolean dragging = false;

    private WindowManager.LayoutParams btnParams;
    private WindowManager.LayoutParams panelParams;

    public FloatingButton(Context ctx, WindowManager wm, ToggleListener l) {
        this.ctx            = ctx;
        this.wm             = wm;
        this.toggleListener = l;
        buildButton();
        buildPanel();
    }

    // ── Botão principal ──────────────────────────────────────────

    private void buildButton() {
        btnView = new View(ctx) {
            private Paint p  = new Paint(Paint.ANTI_ALIAS_FLAG);
            private Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
            {
                tp.setColor(Color.WHITE);
                tp.setTextSize(16f);
                tp.setTextAlign(Paint.Align.CENTER);
            }

            @Override
            protected void onDraw(Canvas c) {
                float r = getWidth() / 2f;
                boolean active = Config.ESP_ENABLED || Config.AIMBOT_ENABLED
                              || Config.RAPID_FIRE_ENABLED || Config.SPEED_ENABLED;
                p.setColor(active ? Color.argb(210, 0, 160, 0)
                                  : Color.argb(210, 160, 0, 0));
                c.drawCircle(r, r, r - 2, p);
                p.setStyle(Paint.Style.STROKE);
                p.setColor(Color.WHITE);
                p.setStrokeWidth(2f);
                c.drawCircle(r, r, r - 2, p);
                p.setStyle(Paint.Style.FILL);

                // Ícone de status
                String line1 = active ? "ON"  : "OFF";
                String line2 = buildStatusLine();
                tp.setTextSize(16f);
                c.drawText(line1, r, r - 2, tp);
                tp.setTextSize(9f);
                c.drawText(line2, r, r + 14, tp);
            }

            private String buildStatusLine() {
                StringBuilder sb = new StringBuilder();
                if (Config.ESP_ENABLED)         sb.append("E");
                if (Config.AIMBOT_ENABLED)       sb.append("A");
                if (Config.RAPID_FIRE_ENABLED)   sb.append("R");
                if (Config.SPEED_ENABLED)        sb.append("S");
                if (Config.ANTI_DETECT_ENABLED)  sb.append("⚡");
                return sb.length() > 0 ? sb.toString() : "---";
            }
        };

        int size = dp(64);
        btnParams = makeParams(size, size, Config.FLOAT_BTN_X, Config.FLOAT_BTN_Y);

        btnView.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    lastX = (int) event.getRawX();
                    lastY = (int) event.getRawY();
                    dragging = false;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    int dx = (int) event.getRawX() - lastX;
                    int dy = (int) event.getRawY() - lastY;
                    if (Math.abs(dx) > 5 || Math.abs(dy) > 5) {
                        dragging = true;
                        btnParams.x += dx;
                        btnParams.y += dy;
                        Config.FLOAT_BTN_X = btnParams.x;
                        Config.FLOAT_BTN_Y = btnParams.y;
                        wm.updateViewLayout(btnView, btnParams);
                    }
                    lastX = (int) event.getRawX();
                    lastY = (int) event.getRawY();
                    return true;
                case MotionEvent.ACTION_UP:
                    if (!dragging) {
                        boolean newState = !(Config.ESP_ENABLED || Config.AIMBOT_ENABLED
                                          || Config.RAPID_FIRE_ENABLED || Config.SPEED_ENABLED);
                        Config.ESP_ENABLED        = newState;
                        Config.AIMBOT_ENABLED     = newState;
                        Config.RAPID_FIRE_ENABLED = newState;
                        Config.SPEED_ENABLED      = newState;
                        btnView.invalidate();
                        fireToggle();
                    }
                    return true;
            }
            return false;
        });

        btnView.setOnLongClickListener(v -> {
            togglePanel();
            return true;
        });
    }

    // ── Painel de configuração completo ──────────────────────────

    private void buildPanel() {
        ScrollView scroll = new ScrollView(ctx);
        scroll.setBackgroundColor(Color.argb(235, 15, 15, 20));

        LinearLayout root = new LinearLayout(ctx);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(14), dp(14), dp(14));

        // ── Título ────────────────────────────────────────────────
        addTitle(root, "⚙  FFTool");
        addDivider(root);

        // ═══════════════════════════════════════════
        // SEÇÃO: ESP
        // ═══════════════════════════════════════════
        addSectionHeader(root, "ESP");
        addToggleRow(root, "ESP Wallhack",
                Config.ESP_ENABLED,
                val -> { Config.ESP_ENABLED = val; btnView.invalidate(); fireToggle(); });
        addToggleRow(root, "Mostrar HP",
                Config.ESP_SHOW_HP,
                val -> Config.ESP_SHOW_HP = val);
        addToggleRow(root, "Mostrar Distância",
                Config.ESP_SHOW_DIST,
                val -> Config.ESP_SHOW_DIST = val);

        // ═══════════════════════════════════════════
        // SEÇÃO: AIMBOT
        // ═══════════════════════════════════════════
        addDivider(root);
        addSectionHeader(root, "AIMBOT");
        addToggleRow(root, "Aimbot",
                Config.AIMBOT_ENABLED,
                val -> { Config.AIMBOT_ENABLED = val; btnView.invalidate(); fireToggle(); });

        addLabel(root, "FOV: " + Config.AIMBOT_FOV + "px", Color.LTGRAY);
        addSlider(root, 20, 400, Config.AIMBOT_FOV, (p, label) -> {
            Config.AIMBOT_FOV = p;
            label.setText("FOV: " + p + "px");
        });

        addLabel(root, "Suavidade: " + (int)(Config.AIMBOT_SMOOTH * 100) + "%", Color.LTGRAY);
        addSlider(root, 0, 100, (int)(Config.AIMBOT_SMOOTH * 100), (p, label) -> {
            Config.AIMBOT_SMOOTH = p / 100f;
            label.setText("Suavidade: " + p + "%");
        });

        addLabel(root, "Alvo:", Color.LTGRAY);
        addBoneSelector(root);

        // ═══════════════════════════════════════════
        // SEÇÃO: VELOCIDADE DE TIRO
        // ═══════════════════════════════════════════
        addDivider(root);
        addSectionHeader(root, "🔫 VELOCIDADE DE TIRO");
        addToggleRow(root, "Rapid Fire",
                Config.RAPID_FIRE_ENABLED,
                val -> { Config.RAPID_FIRE_ENABLED = val; btnView.invalidate(); fireToggle(); });

        addLabel(root, "Delay entre tiros: " + Config.RAPID_FIRE_DELAY_MS + "ms", Color.LTGRAY);
        addLabel(root, "  (menos = mais rápido | mín 30ms recomendado)", Color.DKGRAY);
        addSlider(root, 30, 200, (int) Config.RAPID_FIRE_DELAY_MS, (p, label) -> {
            Config.RAPID_FIRE_DELAY_MS = p;
            label.setText("Delay entre tiros: " + p + "ms");
        });

        addLabel(root, "Duração do tap: " + Config.RAPID_FIRE_TAP_MS + "ms", Color.LTGRAY);
        addSlider(root, 5, 50, (int) Config.RAPID_FIRE_TAP_MS, (p, label) -> {
            Config.RAPID_FIRE_TAP_MS = p;
            label.setText("Duração do tap: " + p + "ms");
        });

        addToggleRow(root, "Auto-detectar posição do botão",
                Config.RAPID_FIRE_AUTO_POS,
                val -> Config.RAPID_FIRE_AUTO_POS = val);

        // Posição manual do botão de disparo
        addLabel(root, "Pos. botão disparo X: " + (int)(Config.RAPID_FIRE_BTN_X_PCT * 100) + "%",
                Color.LTGRAY);
        addSlider(root, 50, 100, (int)(Config.RAPID_FIRE_BTN_X_PCT * 100), (p, label) -> {
            Config.RAPID_FIRE_BTN_X_PCT = p / 100f;
            label.setText("Pos. botão disparo X: " + p + "%");
        });

        addLabel(root, "Pos. botão disparo Y: " + (int)(Config.RAPID_FIRE_BTN_Y_PCT * 100) + "%",
                Color.LTGRAY);
        addSlider(root, 20, 90, (int)(Config.RAPID_FIRE_BTN_Y_PCT * 100), (p, label) -> {
            Config.RAPID_FIRE_BTN_Y_PCT = p / 100f;
            label.setText("Pos. botão disparo Y: " + p + "%");
        });

        // ═══════════════════════════════════════════
        // SEÇÃO: VELOCIDADE DO PERSONAGEM
        // ═══════════════════════════════════════════
        addDivider(root);
        addSectionHeader(root, "⚡ VELOCIDADE DO PERSONAGEM");
        addToggleRow(root, "Speed Hack",
                Config.SPEED_ENABLED,
                val -> { Config.SPEED_ENABLED = val; btnView.invalidate(); fireToggle(); });

        addLabel(root, "Velocidade: " + Config.SPEED_MULTIPLIER + "x", Color.LTGRAY);
        addLabel(root, "  (1.0 = normal | 2.5 = máx sem bug)", Color.DKGRAY);
        addSlider(root, 10, 25, (int)(Config.SPEED_MULTIPLIER * 10), (p, label) -> {
            Config.SPEED_MULTIPLIER = p / 10f;
            label.setText("Velocidade: " + Config.SPEED_MULTIPLIER + "x");
        });

        addLabel(root, "Passo do gesto: " + Config.SPEED_STEP_PX + "px", Color.LTGRAY);
        addSlider(root, 10, 80, Config.SPEED_STEP_PX, (p, label) -> {
            Config.SPEED_STEP_PX = p;
            label.setText("Passo do gesto: " + p + "px");
        });

        addLabel(root, "Intervalo de movimento: " + Config.SPEED_GESTURE_INTERVAL + "ms",
                Color.LTGRAY);
        addSlider(root, 10, 60, (int) Config.SPEED_GESTURE_INTERVAL, (p, label) -> {
            Config.SPEED_GESTURE_INTERVAL = p;
            label.setText("Intervalo de movimento: " + p + "ms");
        });

        addLabel(root, "Modo:", Color.LTGRAY);
        addModeSelector(root,
                new String[]{"Boost Joystick", "Multi-tap"},
                Config.SPEED_MODE,
                idx -> Config.SPEED_MODE = idx);

        addLabel(root, "Pos. joystick X: " + (int)(Config.SPEED_JOYSTICK_X_PCT * 100) + "%",
                Color.LTGRAY);
        addSlider(root, 5, 40, (int)(Config.SPEED_JOYSTICK_X_PCT * 100), (p, label) -> {
            Config.SPEED_JOYSTICK_X_PCT = p / 100f;
            label.setText("Pos. joystick X: " + p + "%");
        });

        addLabel(root, "Pos. joystick Y: " + (int)(Config.SPEED_JOYSTICK_Y_PCT * 100) + "%",
                Color.LTGRAY);
        addSlider(root, 50, 95, (int)(Config.SPEED_JOYSTICK_Y_PCT * 100), (p, label) -> {
            Config.SPEED_JOYSTICK_Y_PCT = p / 100f;
            label.setText("Pos. joystick Y: " + p + "%");
        });

        // ═══════════════════════════════════════════
        // SEÇÃO: ANTI-DETECÇÃO
        // ═══════════════════════════════════════════
        addDivider(root);
        addSectionHeader(root, "🛡 ANTI-DETECÇÃO");
        addToggleRow(root, "Anti-Detecção Ativo",
                Config.ANTI_DETECT_ENABLED,
                val -> Config.ANTI_DETECT_ENABLED = val);
        addToggleRow(root, "Jitter de Timing",
                Config.ANTI_DETECT_ENABLED,
                val -> Config.ANTI_DETECT_ENABLED = val);
        addLabel(root, "Jitter máx: " + Config.ANTI_DETECT_JITTER_MS + "ms", Color.LTGRAY);
        addSlider(root, 0, 30, Config.ANTI_DETECT_JITTER_MS, (p, label) -> {
            Config.ANTI_DETECT_JITTER_MS = p;
            label.setText("Jitter máx: " + p + "ms");
        });
        addToggleRow(root, "Auto-pausar no Anti-Cheat",
                Config.ANTI_DETECT_AUTO_PAUSE,
                val -> Config.ANTI_DETECT_AUTO_PAUSE = val);
        addToggleRow(root, "Throttle em background",
                Config.ANTI_DETECT_BG_THROTTLE,
                val -> Config.ANTI_DETECT_BG_THROTTLE = val);
        addToggleRow(root, "Mascarar overlay",
                Config.ANTI_DETECT_MASK_OVERLAY,
                val -> Config.ANTI_DETECT_MASK_OVERLAY = val);
        addToggleRow(root, "Spoof nome do serviço",
                Config.ANTI_DETECT_SPOOF_SVC,
                val -> Config.ANTI_DETECT_SPOOF_SVC = val);

        // ── Fechar ────────────────────────────────────────────────
        addDivider(root);
        TextView closeBtn = new TextView(ctx);
        closeBtn.setText("✕  Fechar");
        closeBtn.setTextColor(Color.argb(220, 255, 70, 70));
        closeBtn.setTextSize(14f);
        closeBtn.setPadding(dp(4), dp(8), dp(4), dp(4));
        closeBtn.setOnClickListener(v -> togglePanel());
        root.addView(closeBtn);

        scroll.addView(root);
        panelView = scroll;

        panelParams = makeParams(
                dp(300),
                WindowManager.LayoutParams.WRAP_CONTENT,
                Config.FLOAT_BTN_X + dp(68),
                Config.FLOAT_BTN_Y);

        // Altura máxima do painel = 85% da tela
        android.util.DisplayMetrics dm = ctx.getResources().getDisplayMetrics();
        panelParams.height = (int)(dm.heightPixels * 0.85f);
    }

    // ── Helpers de UI ────────────────────────────────────────────

    private interface IntBiConsumer { void accept(int val, TextView label); }
    private interface BoolConsumer  { void accept(boolean val); }
    private interface IntConsumer   { void accept(int val); }

    private void addTitle(LinearLayout p, String text) {
        TextView tv = new TextView(ctx);
        tv.setText(text);
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(17f);
        tv.setPadding(0, 0, 0, dp(4));
        p.addView(tv);
    }

    private void addSectionHeader(LinearLayout p, String text) {
        TextView tv = new TextView(ctx);
        tv.setText(text);
        tv.setTextColor(Color.argb(255, 100, 200, 255));
        tv.setTextSize(13f);
        tv.setPadding(0, dp(4), 0, dp(2));
        p.addView(tv);
    }

    private void addLabel(LinearLayout p, String text, int color) {
        TextView tv = new TextView(ctx);
        tv.setText(text);
        tv.setTextColor(color);
        tv.setTextSize(12f);
        p.addView(tv);
    }

    private void addDivider(LinearLayout p) {
        View d = new View(ctx);
        d.setBackgroundColor(Color.argb(60, 255, 255, 255));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 1);
        lp.setMargins(0, dp(8), 0, dp(8));
        p.addView(d, lp);
    }

    private void addToggleRow(LinearLayout parent, String label,
                               boolean initial, BoolConsumer onChange) {
        LinearLayout row = new LinearLayout(ctx);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(3), 0, dp(3));

        TextView lbl = new TextView(ctx);
        lbl.setText(label);
        lbl.setTextColor(Color.WHITE);
        lbl.setTextSize(13f);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lbl.setLayoutParams(lp);
        row.addView(lbl);

        android.widget.Switch sw = new android.widget.Switch(ctx);
        sw.setChecked(initial);
        sw.setOnCheckedChangeListener((btn, val) -> onChange.accept(val));
        row.addView(sw);
        parent.addView(row);
    }

    private void addSlider(LinearLayout parent, int min, int max, int current,
                            IntBiConsumer onChange) {
        // Label dinâmico (última adicionada = o label acima do slider)
        int childCount = parent.getChildCount();
        TextView dynamicLabel = childCount > 0
                ? (parent.getChildAt(childCount - 1) instanceof TextView
                   ? (TextView) parent.getChildAt(childCount - 1) : null)
                : null;

        SeekBar bar = new SeekBar(ctx);
        bar.setMax(max - min);
        bar.setProgress(current - min);
        final TextView lbl = dynamicLabel;
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean u) {
                if (lbl != null) onChange.accept(p + min, lbl);
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });
        parent.addView(bar);
    }

    private void addBoneSelector(LinearLayout parent) {
        LinearLayout row = new LinearLayout(ctx);
        row.setOrientation(LinearLayout.HORIZONTAL);
        String[] bones = {"Cabeça", "Pescoço", "Tórax"};
        for (int i = 0; i < bones.length; i++) {
            final int idx = i;
            TextView tv = new TextView(ctx);
            tv.setText(bones[i]);
            tv.setTextColor(Color.WHITE);
            tv.setTextSize(12f);
            tv.setPadding(dp(6), dp(3), dp(6), dp(3));
            tv.setBackgroundColor(Config.AIMBOT_TARGET_BONE == idx
                    ? Color.argb(200, 0, 120, 0) : Color.argb(100, 60, 60, 60));
            tv.setOnClickListener(v -> {
                Config.AIMBOT_TARGET_BONE = idx;
                // Atualiza highlight de todos
                for (int j = 0; j < row.getChildCount(); j++) {
                    row.getChildAt(j).setBackgroundColor(
                            j == idx ? Color.argb(200, 0, 120, 0)
                                     : Color.argb(100, 60, 60, 60));
                }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            lp.setMargins(dp(2), 0, dp(2), 0);
            row.addView(tv, lp);
        }
        parent.addView(row);
    }

    private void addModeSelector(LinearLayout parent, String[] options,
                                  int selected, IntConsumer onChange) {
        LinearLayout row = new LinearLayout(ctx);
        row.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < options.length; i++) {
            final int idx = i;
            TextView tv = new TextView(ctx);
            tv.setText(options[i]);
            tv.setTextColor(Color.WHITE);
            tv.setTextSize(12f);
            tv.setPadding(dp(6), dp(3), dp(6), dp(3));
            tv.setBackgroundColor(selected == idx
                    ? Color.argb(200, 0, 100, 180) : Color.argb(100, 60, 60, 60));
            tv.setOnClickListener(v -> {
                onChange.accept(idx);
                for (int j = 0; j < row.getChildCount(); j++) {
                    row.getChildAt(j).setBackgroundColor(
                            j == idx ? Color.argb(200, 0, 100, 180)
                                     : Color.argb(100, 60, 60, 60));
                }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            lp.setMargins(dp(2), 0, dp(2), 0);
            row.addView(tv, lp);
        }
        parent.addView(row);
    }

    private void togglePanel() {
        if (panelOpen) {
            wm.removeView(panelView);
            panelOpen = false;
        } else {
            panelParams.x = Config.FLOAT_BTN_X + dp(68);
            panelParams.y = Config.FLOAT_BTN_Y;
            wm.addView(panelView, panelParams);
            panelOpen = true;
        }
    }

    private void fireToggle() {
        if (toggleListener != null)
            toggleListener.onToggle(Config.ESP_ENABLED, Config.AIMBOT_ENABLED,
                    Config.RAPID_FIRE_ENABLED, Config.SPEED_ENABLED);
    }

    private int dp(int dp) {
        return (int)(dp * ctx.getResources().getDisplayMetrics().density);
    }

    private WindowManager.LayoutParams makeParams(int w, int h, int x, int y) {
        int type = AntiDetect.getOverlayType();
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                w, h, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.LEFT;
        p.x = x;
        p.y = y;
        return p;
    }

    public void attach() { wm.addView(btnView, btnParams); }

    public void detach() {
        try { wm.removeView(btnView); } catch (Exception ignored) {}
        if (panelOpen) try { wm.removeView(panelView); } catch (Exception ignored) {}
    }
}
