package com.fftool.engine;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.graphics.Point;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.WindowManager;

import com.fftool.utils.Config;

import java.util.Random;

/**
 * RapidFireEngine
 * ───────────────
 * Injeta toques rápidos no botão de disparo do Free Fire
 * via AccessibilityService.GestureDescription.
 *
 * Funciona simulando tap-tap-tap no botão de atirar do jogo
 * com delay configurável entre cada disparo.
 *
 * Anti-detecção integrado:
 *  - Jitter aleatório no timing de cada tap
 *  - Variação leve na posição do tap (±3px) para não ser pixel-perfect
 *  - Pausa automática quando AIMBOT está executando gesto (evita conflito)
 */
public class RapidFireEngine {

    private final Handler   handler  = new Handler(Looper.getMainLooper());
    private final Random    rng      = new Random();
    private       Runnable  loop;
    private       boolean   running  = false;

    private AccessibilityService svc;
    private int screenW, screenH;

    public RapidFireEngine(AccessibilityService svc, WindowManager wm) {
        this.svc = svc;
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        screenW = dm.widthPixels;
        screenH = dm.heightPixels;
    }

    // ── API pública ───────────────────────────────────────────────

    public void start() {
        if (running) return;
        running = true;
        scheduleLoop();
    }

    public void stop() {
        running = false;
        handler.removeCallbacksAndMessages(null);
    }

    public boolean isRunning() { return running; }

    // ── Loop de rapid fire ────────────────────────────────────────

    private void scheduleLoop() {
        loop = () -> {
            if (!running || !Config.RAPID_FIRE_ENABLED) {
                handler.postDelayed(loop, 50);
                return;
            }

            performFireTap();

            // Delay base + jitter anti-detecção
            long delay = Config.RAPID_FIRE_DELAY_MS + jitter();
            handler.postDelayed(loop, delay);
        };
        handler.post(loop);
    }

    private void performFireTap() {
        try {
            // Calcula posição do botão de disparo
            int btnX = getFireBtnX();
            int btnY = getFireBtnY();

            // Variação leve na posição (anti-detecção — não é pixel-perfect)
            int jitterX = rng.nextInt(7) - 3; // ±3px
            int jitterY = rng.nextInt(7) - 3;
            btnX += jitterX;
            btnY += jitterY;

            // Duração do tap + pequena variação
            long tapDuration = Config.RAPID_FIRE_TAP_MS + (rng.nextInt(5));

            Path path = new Path();
            path.moveTo(btnX, btnY);

            GestureDescription.Builder builder = new GestureDescription.Builder();
            builder.addStroke(new GestureDescription.StrokeDescription(
                    path, 0, tapDuration));

            svc.dispatchGesture(builder.build(), null, null);

        } catch (Exception ignored) {
            // Falha silenciosa — tenta no próximo tick
        }
    }

    // ── Posição do botão de disparo ───────────────────────────────

    private int getFireBtnX() {
        if (Config.RAPID_FIRE_AUTO_POS) {
            // Free Fire: botão de disparo no lado direito
            // Posição padrão calibrada para layout standard
            return (int)(screenW * 0.85f);
        }
        return (int)(screenW * Config.RAPID_FIRE_BTN_X_PCT);
    }

    private int getFireBtnY() {
        if (Config.RAPID_FIRE_AUTO_POS) {
            return (int)(screenH * 0.70f);
        }
        return (int)(screenH * Config.RAPID_FIRE_BTN_Y_PCT);
    }

    // ── Jitter de timing ─────────────────────────────────────────

    private long jitter() {
        if (!Config.ANTI_DETECT_ENABLED) return 0;
        return rng.nextInt(Config.ANTI_DETECT_JITTER_MS + 1);
    }
}
