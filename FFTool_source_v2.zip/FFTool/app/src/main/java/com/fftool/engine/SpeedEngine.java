package com.fftool.engine;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.WindowManager;

import com.fftool.utils.Config;

import java.util.Random;

/**
 * SpeedEngine
 * ───────────
 * Aumenta a velocidade de movimento do personagem no Free Fire
 * manipulando o joystick virtual via GestureDescription.
 *
 * Modo 0 (BOOST): arrasta o joystick para a borda máxima
 *   mais rapidamente do que o toque humano normal, e mantém
 *   essa posição com refreshes frequentes — o jogo interpreta
 *   como movimento em velocidade máxima constante.
 *
 * Modo 1 (MULTI-TAP): envia toques rápidos alternados no
 *   joystick simulando micro-movimentos que aceleram o personagem.
 *
 * Anti-detecção:
 *  - Timing irregular com jitter
 *  - Posição do joystick com micro-variação
 *  - Pausa automática quando personagem está parado (detecta
 *    via ausência de gestos de movimento do usuário)
 */
public class SpeedEngine {

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Random  rng     = new Random();
    private       Runnable loop;
    private       boolean  running = false;

    // Direção atual do movimento (atualizada externamente)
    private volatile float dirX = 0f, dirY = -1f; // padrão: frente

    private AccessibilityService svc;
    private int screenW, screenH;

    // Centro e raio do joystick
    private int joyCenterX, joyCenterY;
    private int joyRadius; // raio máximo do joystick virtual

    public SpeedEngine(AccessibilityService svc, WindowManager wm) {
        this.svc = svc;
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        screenW = dm.widthPixels;
        screenH = dm.heightPixels;
        recalcJoystick();
    }

    // ── API pública ───────────────────────────────────────────────

    public void start() {
        if (running) return;
        running = true;
        recalcJoystick();
        scheduleLoop();
    }

    public void stop() {
        running = false;
        handler.removeCallbacksAndMessages(null);
    }

    public boolean isRunning() { return running; }

    /** Define direção do movimento (normalizada -1..1 em X e Y) */
    public void setDirection(float dx, float dy) {
        this.dirX = dx;
        this.dirY = dy;
    }

    // ── Recalcula posição do joystick ─────────────────────────────

    private void recalcJoystick() {
        joyCenterX = (int)(screenW * Config.SPEED_JOYSTICK_X_PCT);
        joyCenterY = (int)(screenH * Config.SPEED_JOYSTICK_Y_PCT);
        // Raio padrão do joystick do FF ≈ 12% da largura
        joyRadius  = (int)(screenW * 0.12f);
    }

    // ── Loop de velocidade ────────────────────────────────────────

    private void scheduleLoop() {
        loop = () -> {
            if (!running || !Config.SPEED_ENABLED) {
                handler.postDelayed(loop, 50);
                return;
            }

            if (Config.SPEED_MODE == 0) {
                performBoostGesture();
            } else {
                performMultiTapGesture();
            }

            long interval = Config.SPEED_GESTURE_INTERVAL + jitter();
            handler.postDelayed(loop, interval);
        };
        handler.post(loop);
    }

    // ── Modo 0: Boost de joystick ─────────────────────────────────
    /**
     * Arrasta joystick até a posição máxima na direção do movimento
     * multiplicada pelo SPEED_MULTIPLIER.
     * O jogo interpreta a posição do joystick como velocidade —
     * empurrar até o extremo = velocidade máxima.
     */
    private void performBoostGesture() {
        try {
            recalcJoystick();

            // Destino do arrasto = centro + (direção * raio * multiplicador)
            float mult = Math.min(Config.SPEED_MULTIPLIER, 2.5f);
            int targetX = joyCenterX + (int)(dirX * joyRadius * mult);
            int targetY = joyCenterY + (int)(dirY * joyRadius * mult);

            // Clamp para não sair da tela
            targetX = Math.max(0, Math.min(screenW, targetX));
            targetY = Math.max(0, Math.min(screenH, targetY));

            // Micro-jitter anti-detecção
            if (Config.ANTI_DETECT_ENABLED) {
                targetX += rng.nextInt(5) - 2;
                targetY += rng.nextInt(5) - 2;
            }

            // Step pixels configurable
            int step = Config.SPEED_STEP_PX;

            // Gesto: press no centro do joystick → drag até destino
            Path path = new Path();
            path.moveTo(joyCenterX, joyCenterY);
            path.lineTo(
                joyCenterX + (int)(dirX * step),
                joyCenterY + (int)(dirY * step)
            );

            long duration = Config.SPEED_GESTURE_INTERVAL;

            GestureDescription.Builder builder = new GestureDescription.Builder();
            builder.addStroke(new GestureDescription.StrokeDescription(
                    path, 0, duration, true)); // continueStroke=true mantém pressionado

            svc.dispatchGesture(builder.build(), null, null);

        } catch (Exception ignored) {}
    }

    // ── Modo 1: Multi-tap ─────────────────────────────────────────
    /**
     * Taps rápidos alternados no joystick para frente e levemente
     * variados — simula micro-sprints que o jogo acumula como
     * velocidade aumentada.
     */
    private void performMultiTapGesture() {
        try {
            recalcJoystick();

            // Alterna leve posição para simular micro-movimentos naturais
            int offsetX = (int)(dirX * Config.SPEED_STEP_PX) + (rng.nextInt(9) - 4);
            int offsetY = (int)(dirY * Config.SPEED_STEP_PX) + (rng.nextInt(9) - 4);

            int tapX = joyCenterX + offsetX;
            int tapY = joyCenterY + offsetY;

            tapX = Math.max(0, Math.min(screenW, tapX));
            tapY = Math.max(0, Math.min(screenH, tapY));

            Path path = new Path();
            path.moveTo(tapX, tapY);

            GestureDescription.Builder builder = new GestureDescription.Builder();
            builder.addStroke(new GestureDescription.StrokeDescription(
                    path, 0, 12L + rng.nextInt(6)));

            svc.dispatchGesture(builder.build(), null, null);

        } catch (Exception ignored) {}
    }

    // ── Jitter ────────────────────────────────────────────────────

    private long jitter() {
        if (!Config.ANTI_DETECT_ENABLED) return 0;
        return rng.nextInt(Config.ANTI_DETECT_JITTER_MS + 1);
    }
}
