package com.fftool.utils;

import android.graphics.Color;

/**
 * Config central — todos os parâmetros ajustáveis do FFTool.
 * Modifique aqui ou pelo overlay de configuração em runtime.
 */
public final class Config {

    // ── Pacote alvo ──────────────────────────────────────────────
    public static final String FF_PACKAGE = "com.dts.freefireth";

    // ── Toggles globais ──────────────────────────────────────────
    public static volatile boolean ESP_ENABLED    = true;
    public static volatile boolean AIMBOT_ENABLED = true;

    // ── ESP ──────────────────────────────────────────────────────
    public static volatile int     ESP_COLOR_DEFAULT  = Color.RED;
    public static volatile int     ESP_COLOR_LOCKED   = Color.YELLOW;
    public static volatile float   ESP_LINE_WIDTH     = 2.5f;
    public static volatile boolean ESP_SHOW_HP        = true;
    public static volatile boolean ESP_SHOW_DIST      = true;
    public static volatile boolean ESP_SHOW_NAME      = false;
    public static volatile boolean ESP_WALLHACK       = true;

    // ── Aimbot ───────────────────────────────────────────────────
    public static volatile int     AIMBOT_FOV          = 180;
    public static volatile float   AIMBOT_SMOOTH       = 0.35f;
    public static volatile int     AIMBOT_TARGET_BONE  = 0;
    public static volatile boolean AIMBOT_TRIGGERBOT   = false;
    public static volatile long    AIMBOT_DELAY_MS     = 16L;

    // ── Detecção de cor (ESP via pixel) ──────────────────────────
    public static final int ENEMY_OUTLINE_COLOR = Color.rgb(220, 220, 220);
    public static final int COLOR_TOLERANCE     = 30;

    // ── Resolução de referência ───────────────────────────────────
    public static final int REF_WIDTH  = 1280;
    public static final int REF_HEIGHT = 720;

    // ── Overlay ───────────────────────────────────────────────────
    public static int FLOAT_BTN_X = 20;
    public static int FLOAT_BTN_Y = 300;

    // ══════════════════════════════════════════════════════════════
    // ── VELOCIDADE DE TIRO ────────────────────────────────────────
    // ══════════════════════════════════════════════════════════════
    /** Ativa injeção de tiros rápidos via gestos de disparo */
    public static volatile boolean RAPID_FIRE_ENABLED  = false;

    /**
     * Delay entre cada gesto de disparo (ms).
     * Padrão do jogo ≈ 100ms. Reduza para disparar mais rápido.
     * Mínimo recomendado: 30ms (abaixo disso pode bugar animação).
     * Range ajustável: 30–200ms.
     */
    public static volatile long RAPID_FIRE_DELAY_MS    = 60L;

    /**
     * Duração do gesto de toque (ms).
     * Simula pressionar o botão de disparo.
     * 10ms = toque instantâneo, 30ms = toque mais natural.
     */
    public static volatile long RAPID_FIRE_TAP_MS      = 15L;

    /**
     * Posição do botão de disparo na tela (lado direito).
     * Será auto-detectado se RAPID_FIRE_AUTO_POS = true.
     * Padrão Free Fire: 85% da largura, 70% da altura.
     */
    public static volatile float RAPID_FIRE_BTN_X_PCT  = 0.85f;
    public static volatile float RAPID_FIRE_BTN_Y_PCT  = 0.70f;
    public static volatile boolean RAPID_FIRE_AUTO_POS = true;

    // ══════════════════════════════════════════════════════════════
    // ── VELOCIDADE DO PERSONAGEM ──────────────────────────────────
    // ══════════════════════════════════════════════════════════════
    /** Ativa boost de velocidade de movimento */
    public static volatile boolean SPEED_ENABLED       = false;

    /**
     * Multiplicador de velocidade.
     * 1.0 = velocidade normal.
     * 1.5 = 50% mais rápido.
     * 2.0 = dobro da velocidade.
     * Máximo recomendado: 2.5 (acima pode causar rubber-band).
     */
    public static volatile float SPEED_MULTIPLIER      = 1.5f;

    /**
     * Intervalo entre gestos de movimento (ms).
     * Menor = mais suave/rápido, mas mais CPU.
     * Recomendado: 16–32ms.
     */
    public static volatile long SPEED_GESTURE_INTERVAL = 20L;

    /**
     * Comprimento do gesto de movimento por tick (pixels).
     * Maior = passo maior = movimento mais rápido.
     * Range: 10–80px.
     */
    public static volatile int SPEED_STEP_PX           = 30;

    /**
     * Modo de velocidade:
     * 0 = boost de joystick (move joystick virtual mais rápido)
     * 1 = multi-tap (taps rápidos no joystick para simular sprinting)
     */
    public static volatile int SPEED_MODE              = 0;

    /**
     * Posição do joystick virtual no Free Fire.
     * Padrão: lado esquerdo, 15% X, 75% Y.
     */
    public static volatile float SPEED_JOYSTICK_X_PCT  = 0.15f;
    public static volatile float SPEED_JOYSTICK_Y_PCT  = 0.75f;

    // ══════════════════════════════════════════════════════════════
    // ── ANTI-DETECÇÃO ─────────────────────────────────────────────
    // ══════════════════════════════════════════════════════════════
    /** Ativa todos os módulos de anti-detecção */
    public static volatile boolean ANTI_DETECT_ENABLED = true;

    /**
     * Jitter de timing — adiciona variação aleatória nos delays
     * dos gestos para não criar padrão detectável pelo anti-cheat.
     * Range: 0–20ms de variação extra.
     */
    public static volatile int ANTI_DETECT_JITTER_MS   = 8;

    /**
     * Ofusca o nome do serviço de acessibilidade nas queries
     * do sistema para dificultar detecção por nome de processo.
     */
    public static volatile boolean ANTI_DETECT_SPOOF_SVC = true;

    /**
     * Pausa automática quando FF detecta tela de anti-cheat
     * (janela de verificação). Resume após janela fechar.
     */
    public static volatile boolean ANTI_DETECT_AUTO_PAUSE = true;

    /**
     * Intervalo de heartbeat do serviço (ms).
     * Valor irregular dificulta detecção por padrão de timing.
     * Padrão: 997ms (primo — evita sincronizar com varreduras de 1s).
     */
    public static volatile long ANTI_DETECT_HEARTBEAT_MS = 997L;

    /**
     * Limita FPS dos scans ESP quando FF está em background
     * para reduzir assinatura de CPU detectável.
     */
    public static volatile boolean ANTI_DETECT_BG_THROTTLE = true;

    /**
     * Mascara o overlay como widget do sistema
     * usando TYPE_ACCESSIBILITY_OVERLAY ao invés de
     * TYPE_APPLICATION_OVERLAY quando possível.
     */
    public static volatile boolean ANTI_DETECT_MASK_OVERLAY = true;

    private Config() {}
}
